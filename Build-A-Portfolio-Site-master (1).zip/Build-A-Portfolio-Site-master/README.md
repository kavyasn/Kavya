# Build A Portfolio Website

**Summary:**

This webpage was created specifically for [Udacity's Front End Developer Developer Nanodegree](https://www.udacity.com).

**The application offers the following features:**

* Creating a web page that is replicated for the project requirement.
* Bold/Italiacs
* Image Views

**Technologies Used In Application:**

* HTML
* CSS

**Testing The Web Page:**

* Download the project to your computer.
* Right click and open with Google Chrome browser.

**Closing:**

In conclusion, I have learned a lot by working on this project. I am confident that I mastered HTML, as well as CSS and am able to successfully create web pages using different features.
